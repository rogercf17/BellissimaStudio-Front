import { Calendar, Home, Plus, User } from "lucide-react"
import { NavLink } from "react-router-dom"

const menuItems = [
    { label: 'Home', icon: Home, path: '/home' },
    { label: 'Calendário', icon: Calendar, path: '/calendario' },
    { label: 'Criar Agendamento', icon: Plus, path: '/criar' },
]

export const Sidebar = () => {
    return(
        <aside className="w-64 h-screen sticky top-0 shrink-0 bg-bordeaux text-blush flex flex-col">
            <div className="px-6 py-8 border-b border-white/10">
                <h1 className="font-serif text-3xl text-white leading-none">Bellíssima</h1>
                <p className="mt-2 text-xs tracking-[0.35em] text-champagne">STUDIO</p>
            </div>

            <nav className="mt-4 flex flex-col gap-1 px-3">
                {menuItems.map(({ label, icon: Icon, path }) => (
                    <NavLink
                        key={path}
                        to={path}
                        className={({ isActive }) =>
                            `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition border-l-2 ${
                                isActive
                                ? 'bg-bordeaux-dark text-white font-medium border-champagne'
                                : 'text-blush-deep border-transparent hover:bg-white/10 hover:text-white'
                            }`
                        }
                    >
                        <Icon size={18} />
                        {label}
                    </NavLink>
                ))}
            </nav>

            <div className="mt-auto px-6 py-5 border-t border-white/10 flex items-center gap-3">
                <span className="flex h-8 w-8 items-center justify-center rounded-full bg-bordeaux-dark text-champagne">
                    <User size={16} />
                </span>
                <span className="text-sm text-white">Administrador</span>
            </div>
        </aside>
    )
}